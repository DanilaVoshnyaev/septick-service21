<?php

/**
 * Activator for the Update manager
 *
 * @author        Alex Kovalev <alex.kovalevv@gmail.com>, Github: https://github.com/alexkovalevv
 * @copyright (c) 09.09.2017, Webcraftic
 * @see           Factory469_Activator
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WUPM_Activation extends Wbcr_Factory469_Activator {

	/**
	 * Runs activation actions.
	 *
	 * @since 1.0.0
	 */
	public function activate() {

	}

	/**
	 * Runs deactivation actions.
	 *
	 * @since 1.0.0
	 */
	public function deactivate() {

	}


}
